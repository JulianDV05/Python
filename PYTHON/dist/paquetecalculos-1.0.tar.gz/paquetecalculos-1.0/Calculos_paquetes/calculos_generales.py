def sumar(num1, num2):
    print(f"El resultado de la suma es: {num1+num2}")

def restar(num1, num2):
    print(f"El resultado de la resta es: {num1-num2}")

def multiplicar(num1, num2):
    print(f"El resultado de la multiplicación es: {num1*num2}")

def dividir(dividendo, divisor):
    print(f"El resultado de la división es: {dividendo/divisor}")

def potencia(base, exponente):
    print(f"El resultado de la potencia es: {base**exponente}")

def redondear(numero):
    print(f"El resultado es: {round(numero)}")