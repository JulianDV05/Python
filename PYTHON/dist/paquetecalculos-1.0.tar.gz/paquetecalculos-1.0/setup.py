from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="paquete de redondeo y potencia",
    author="Julian Valencia",
    author_email="valenciajulian657@gmail.com",
    url="www.pildorasinformaticas.es",
    packages=["Calculos_paquetes", "Calculos_paquetes.redondeo_potencia"]
)